# main.py – FastAPI backend entry point (placeholder)
# Ovde ćeš nalepiti tvoj kompletan backend kod koji smo već napravili u Canvasi